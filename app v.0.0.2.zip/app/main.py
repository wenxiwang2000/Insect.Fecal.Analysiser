"""
TURD‑like spot detector — organized layout with bottom export bar.

This file contains the full Streamlit application originally provided as `Main.py`.  The app lets users upload an image, draw a rectangular or circular ROI, adjust detection parameters, visualise the results and export CSV/PNG files.  It relies on OpenCV, NumPy, Pandas, Pillow and the `streamlit_drawable_canvas` component.

To run this app, install the dependencies from `requirements.txt` and execute:

    streamlit run main.py

See the accompanying `README.md` for detailed usage instructions.
"""

from __future__ import annotations

import json
import math
from io import BytesIO
from dataclasses import asdict, dataclass
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np
import pandas as pd
import streamlit as st
from PIL import Image

# -----------------------------------------------------------------------------
# Monkey‑patch Streamlit for compatibility with newer versions
#
# The streamlit-drawable-canvas component relies on the internal
# `image_to_url` helper on `streamlit.elements.image`. In Streamlit 1.41+ this
# helper was moved to `streamlit.elements.lib.image_utils` which breaks
# downstream packages expecting the old API. To remain compatible with both
# older and newer Streamlit releases, we detect the missing attribute and
# re‑assign it from its new location. If either import fails we silently
# ignore the error, leaving the attribute unchanged on older versions.

try:
    # Import the image module where image_to_url originally lived
    from streamlit.elements import image as _st_image  # type: ignore
    # Only patch if the attribute is missing
    if not hasattr(_st_image, "image_to_url"):
        try:
            # New location in newer versions of Streamlit
            from streamlit.elements.lib import image_utils as _image_utils  # type: ignore
            _st_image.image_to_url = _image_utils.image_to_url  # type: ignore
        except Exception:
            # Fall back to alternative import paths
            try:
                # Some versions expose image_to_url under the public API
                from streamlit import image_util as _fallback_image_util  # type: ignore
                _st_image.image_to_url = _fallback_image_util.image_to_url  # type: ignore
            except Exception:
                # Unable to patch; proceed without modification
                pass
except Exception:
    # Ignore any import or attribute errors; patching is optional
    pass

from streamlit_drawable_canvas import st_canvas


@dataclass
class ROI:
    """Region of interest descriptor for rectangular or circular selection."""

    kind: str  # "rect" or "circle"
    x0: int
    y0: int
    x1: int
    y1: int
    cx: Optional[int] = None
    cy: Optional[int] = None
    r: Optional[int] = None

    def clamp(self, w: int, h: int) -> "ROI":
        """Clamp ROI coordinates to image bounds and preserve shape semantics."""
        x0 = int(max(0, min(self.x0, w - 1)))
        x1 = int(max(1, min(self.x1, w)))
        y0 = int(max(0, min(self.y0, h - 1)))
        y1 = int(max(1, min(self.y1, h)))
        if x1 <= x0:
            x1 = min(w, x0 + 1)
        if y1 <= y0:
            y1 = min(h, y0 + 1)

        out = ROI(self.kind, x0, y0, x1, y1, self.cx, self.cy, self.r)

        # For circles, clamp centre and radius and recompute bounding box.
        if out.kind == "circle" and out.cx is not None and out.cy is not None and out.r is not None:
            cx = int(max(0, min(out.cx, w - 1)))
            cy = int(max(0, min(out.cy, h - 1)))
            r = int(max(1, out.r))
            x0 = int(max(0, min(cx - r, w - 1)))
            y0 = int(max(0, min(cy - r, h - 1)))
            x1 = int(max(x0 + 1, min(cx + r, w)))
            y1 = int(max(y0 + 1, min(cy + r, h)))
            out.cx, out.cy, out.r = cx, cy, r
            out.x0, out.y0, out.x1, out.y1 = x0, y0, x1, y1
        return out


def white_candidate_mask_hsv(bgr: np.ndarray, s_max: int = 40, v_min: int = 220) -> np.ndarray:
    """Compute a binary mask of "white-ish" pixels in HSV space."""
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    _, s, v = cv2.split(hsv)
    return (((s <= s_max) & (v >= v_min)).astype(np.uint8) * 255)

# -----------------------------------------------------------------------------
# Background colour presets and sampling utility
#
# For convenience and reproducibility we support a small set of predefined
# background colours.  Each entry maps a human‑friendly name to HSV ranges
# `(h_low, h_high, s_min, v_min)`.  These ranges are used as defaults when
# the user selects a preset in the UI.  See the documentation for details.
#
# In addition, we provide a helper to compute a robust HSV range from an
# arbitrary rectangular region of an image.  This helper calculates
# percentile‑based bounds on the H, S and V channels, which makes the mask
# resilient to outliers and noise.

# Mapping from colour names to HSV threshold tuples
PRESET_BG_COLORS: Dict[str, Tuple[int, int, int, int]] = {
    "Pink": (145, 179, 40, 0),
    "Blue": (100, 140, 40, 0),
    "Yellow": (15, 35, 40, 0),
    "Green": (45, 90, 40, 0),
    "Custom": (0, 179, 0, 0),
}

def compute_sample_hsv_range(
    bgr: np.ndarray,
    rect: Tuple[int, int, int, int],
    h_bounds: Tuple[float, float] = (0.05, 0.95),
    s_bounds: Tuple[float, float] = (0.05, 1.0),
    v_bounds: Tuple[float, float] = (0.05, 1.0),
) -> Tuple[int, int, int, int]:
    """
    Compute a robust HSV threshold range from a rectangular region.

    The returned values `(h_low, h_high, s_min, v_min)` are percentiles
    of the H, S and V channels in the provided region.  Hue values wrap
    around at 180, so this routine assumes the sampled distribution does not
    cross the 0/179 boundary.  Saturation and value thresholds are expressed
    as lower bounds only.

    Parameters
    ----------
    bgr : np.ndarray
        Input image in BGR colour space.
    rect : Tuple[int, int, int, int]
        Coordinates `(x0, y0, x1, y1)` defining the sampling region.
    h_bounds : Tuple[float, float], optional
        Lower and upper percentiles for hue (in [0,1]), by default (0.05, 0.95).
    s_bounds : Tuple[float, float], optional
        Lower and upper percentiles for saturation, by default (0.05, 1.0).
    v_bounds : Tuple[float, float], optional
        Lower and upper percentiles for value, by default (0.05, 1.0).

    Returns
    -------
    Tuple[int, int, int, int]
        `(h_low, h_high, s_min, v_min)` suitable for thresholding.
    """
    x0, y0, x1, y1 = rect
    # Clamp coordinates to image bounds
    h_img, w_img = bgr.shape[:2]
    x0 = max(0, min(int(x0), w_img - 1))
    x1 = max(0, min(int(x1), w_img))
    y0 = max(0, min(int(y0), h_img - 1))
    y1 = max(0, min(int(y1), h_img))
    if x1 <= x0 or y1 <= y0:
        return (0, 179, 0, 0)
    region = bgr[y0:y1, x0:x1]
    hsv = cv2.cvtColor(region, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    # Flatten arrays to 1D
    h_vals = h.reshape(-1)
    s_vals = s.reshape(-1)
    v_vals = v.reshape(-1)
    # Compute percentiles
    h_low_val = float(np.percentile(h_vals, h_bounds[0] * 100.0))
    h_high_val = float(np.percentile(h_vals, h_bounds[1] * 100.0))
    s_min_val = float(np.percentile(s_vals, s_bounds[0] * 100.0))
    v_min_val = float(np.percentile(v_vals, v_bounds[0] * 100.0))
    # Cast to ints and clamp to valid ranges
    h_low_i = int(max(0, min(round(h_low_val), 179)))
    h_high_i = int(max(0, min(round(h_high_val), 179)))
    s_min_i = int(max(0, min(round(s_min_val), 255)))
    v_min_i = int(max(0, min(round(v_min_val), 255)))
    return h_low_i, h_high_i, s_min_i, v_min_i



@dataclass
class Params:
    """Parameters controlling spot detection and post-processing."""

    min_area: int = 10
    max_area: int = 4000
    sensitivity: int = 200
    n_flies: int = 8
    # Background and arena settings
    # background_method selects how background pixels are excluded:
    #   "none"   -> no background mask applied;
    #   "preset" -> apply a preset HSV mask defined by bg_color_preset;
    #   "sample" -> derive HSV thresholds from a user drawn sampling region;
    background_method: str = "preset"
    bg_color_preset: str = "Pink"
    # remove_pink_background is retained for backwards compatibility; when True
    # and background_method is "preset", the preset mask will be applied.
    remove_pink_background: bool = True
    # When background_method == "sample", sample_rect holds the crop-space
    # coordinates (x0,y0,x1,y1) of the sampled region.
    sample_rect: Optional[Tuple[int, int, int, int]] = None
    use_arenas: bool = True
    rod_circularity_cutoff: float = 0.60
    morph_open: int = 3
    morph_close: int = 7
    pink_h_low: int = 145
    pink_h_high: int = 179
    pink_s_min: int = 40
    pink_v_min: int = 0
    pink_close: int = 9
    arena_s_max: int = 40
    arena_v_min: int = 220
    arena_close: int = 15
    arena_erode: int = 9
    arena_min_area: int = 20000
    arena_max_area: int = 400000
    adaptive_block_size: int = 31
    adaptive_offset_c: int = 10


def resize_for_display(img: Image.Image, max_w: int = 1100) -> Tuple[Image.Image, float]:
    """Resize image to fit within the UI while preserving aspect ratio."""
    w, _h = img.size
    if w <= max_w:
        return img, 1.0
    scale = max_w / float(w)
    return img.resize((int(w * scale), int(img.size[1] * scale))), scale


def pil_to_bgr(img: Image.Image) -> np.ndarray:
    rgb = np.array(img.convert("RGB"))
    return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)


def bgr_to_pil(bgr: np.ndarray) -> Image.Image:
    return Image.fromarray(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB))


def apply_mask_alpha(pil_img: Image.Image, mask_u8: np.ndarray) -> Image.Image:
    """Return an RGBA image where the alpha channel comes from the provided mask."""
    if mask_u8.dtype != np.uint8:
        mask_u8 = mask_u8.astype(np.uint8)
    rgba = np.array(pil_img.convert("RGBA"))
    rgba[:, :, 3] = mask_u8
    return Image.fromarray(rgba, mode="RGBA")


def _get_last_shape(canvas_json: Dict, kind: str) -> Optional[Dict]:
    if not canvas_json or "objects" not in canvas_json:
        return None
    shapes = [o for o in canvas_json["objects"] if o.get("type") == kind]
    return shapes[-1] if shapes else None


def roi_from_canvas(canvas_json: Dict, draw_mode: str, scale: float) -> Optional[ROI]:
    shape = _get_last_shape(canvas_json, "rect" if draw_mode == "rect" else "circle")
    if not shape:
        return None
    left = float(shape.get("left", 0))
    top = float(shape.get("top", 0))
    sx = float(shape.get("scaleX", 1.0))
    sy = float(shape.get("scaleY", 1.0))
    if draw_mode == "rect":
        w = float(shape.get("width", 0)) * sx
        h = float(shape.get("height", 0)) * sy
        x0 = int(left / scale)
        y0 = int(top / scale)
        x1 = int((left + w) / scale)
        y1 = int((top + h) / scale)
        return ROI("rect", x0, y0, x1, y1)
    # circle
    r = float(shape.get("radius", 0))
    s = (sx + sy) / 2.0  # keep circular
    rr = r * s
    cx = (left + rr) / scale
    cy = (top + rr) / scale
    r0 = rr / scale
    cx_i = int(round(cx))
    cy_i = int(round(cy))
    r_i = int(round(r0))
    return ROI("circle", cx_i - r_i, cy_i - r_i, cx_i + r_i, cy_i + r_i, cx=cx_i, cy=cy_i, r=r_i)


def make_roi_mask(w: int, h: int, roi: ROI) -> np.ndarray:
    m = np.zeros((h, w), dtype=np.uint8)
    if roi.kind == "rect":
        m[roi.y0 : roi.y1, roi.x0 : roi.x1] = 255
    else:
        assert roi.cx is not None and roi.cy is not None and roi.r is not None
        cv2.circle(m, (roi.cx, roi.cy), roi.r, 255, thickness=-1)
    return m


def adaptive_threshold(gray: np.ndarray, block_size: int, c: int) -> np.ndarray:
    block_size = max(3, int(block_size))
    if block_size % 2 == 0:
        block_size += 1
    return cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, block_size, int(c)
    )


def morphology(bw: np.ndarray, open_k: int, close_k: int) -> np.ndarray:
    out = bw
    if open_k > 1:
        k = np.ones((open_k, open_k), np.uint8)
        out = cv2.morphologyEx(out, cv2.MORPH_OPEN, k, iterations=1)
    if close_k > 1:
        k = np.ones((close_k, close_k), np.uint8)
        out = cv2.morphologyEx(out, cv2.MORPH_CLOSE, k, iterations=1)
    return out


def circularity(area: float, peri: float) -> float:
    if peri <= 0:
        return 0.0
    return float(4.0 * math.pi * area / (peri * peri))


def pink_background_mask_hsv(
    bgr: np.ndarray,
    h_low: int = 145,
    h_high: int = 179,
    s_min: int = 40,
    v_min: int = 0,
    close_k: int = 9,
) -> np.ndarray:
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    if h_low <= h_high:
        in_h = (h >= h_low) & (h <= h_high)
    else:
        in_h = (h >= h_low) | (h <= h_high)
    pink = in_h & (s >= s_min) & (v >= v_min)
    m = (pink.astype(np.uint8) * 255)
    if close_k and close_k > 1:
        k = np.ones((close_k, close_k), np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, k, iterations=1)
    return m


def detect_arenas_white_regions(
    bgr: np.ndarray,
    s_max: int = 40,
    v_min: int = 220,
    close_k: int = 15,
    erode_k: int = 9,
    min_area: int = 20000,
    max_area: int = 400000,
) -> np.ndarray:
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    _, s, v = cv2.split(hsv)
    mask = ((s <= s_max) & (v >= v_min)).astype(np.uint8) * 255
    if close_k > 1:
        k = np.ones((close_k, close_k), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k, iterations=1)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    out = np.zeros_like(mask)
    for c in contours:
        a = cv2.contourArea(c)
        if a < min_area or a > max_area:
            continue
        cv2.drawContours(out, [c], -1, 255, thickness=-1)
    if erode_k and erode_k > 1:
        k = np.ones((erode_k, erode_k), np.uint8)
        out = cv2.erode(out, k, iterations=1)
    return out


def measure_spots_turd_style(
    bgr: np.ndarray,
    bw: np.ndarray,
    min_area: int,
    max_area: int,
    rod_circ_cutoff: float,
) -> Tuple[pd.DataFrame, np.ndarray]:
    hls = cv2.cvtColor(bgr, cv2.COLOR_BGR2HLS)
    contours, _ = cv2.findContours(bw, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    rows: List[Dict] = []
    spot_union = np.zeros(bw.shape, dtype=np.uint8)
    did = 0
    for c in contours:
        a = float(cv2.contourArea(c))
        if a < min_area or a > max_area:
            continue
        p = float(cv2.arcLength(c, True))
        circ = circularity(a, p)
        m = np.zeros(bw.shape, dtype=np.uint8)
        cv2.drawContours(m, [c], -1, 255, thickness=-1)
        spot_union = cv2.bitwise_or(spot_union, m)
        M = cv2.moments(c)
        if M["m00"] != 0:
            cx = float(M["m10"] / M["m00"])
            cy = float(M["m01"] / M["m00"])
        else:
            cx, cy = float("nan"), float("nan")
        mean_b, mean_g, mean_r, _ = cv2.mean(bgr, mask=m)
        mean_h, mean_l, mean_s, _ = cv2.mean(hls, mask=m)
        mean_h_deg = (mean_h * 2.0) % 360.0
        mean_l_n = mean_l / 255.0
        mean_s_n = mean_s / 255.0
        iod = a * (1.0 - mean_l_n)
        rod = 1 if circ < rod_circ_cutoff else 0
        did += 1
        rows.append(
            {
                "DepositID": did,
                "X": cx,
                "Y": cy,
                "Area_px": a,
                "Perimeter_px": p,
                "Circularity": circ,
                "ROD": rod,
                "IOD": iod,
                "MeanR": mean_r / 255.0,
                "MeanG": mean_g / 255.0,
                "MeanB": mean_b / 255.0,
                "MeanH_deg": mean_h_deg,
                "MeanL": mean_l_n,
                "MeanS": mean_s_n,
            }
        )
    df = pd.DataFrame(rows) if rows else pd.DataFrame(
        columns=[
            "DepositID",
            "X",
            "Y",
            "Area_px",
            "Perimeter_px",
            "Circularity",
            "ROD",
            "IOD",
            "MeanR",
            "MeanG",
            "MeanB",
            "MeanH_deg",
            "MeanL",
            "MeanS",
        ]
    )
    return df, spot_union


def plate_summary(df: pd.DataFrame, n_flies: int) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame([
            {
                "N_spots": 0,
                "TotalArea_px": 0.0,
                "TotalIOD": 0.0,
                "N_flies": int(n_flies),
                "Spots_per_fly": np.nan,
                "Area_per_fly": np.nan,
                "IOD_per_fly": np.nan,
            }
        ])
    n = int(df.shape[0])
    total_area = float(df["Area_px"].sum())
    total_iod = float(df["IOD"].sum())
    out = {
        "N_spots": n,
        "TotalArea_px": total_area,
        "TotalIOD": total_iod,
        "N_flies": int(n_flies),
    }
    if n_flies and n_flies > 0:
        out["Spots_per_fly"] = n / float(n_flies)
        out["Area_per_fly"] = total_area / float(n_flies)
        out["IOD_per_fly"] = total_iod / float(n_flies)
    else:
        out["Spots_per_fly"] = np.nan
        out["Area_per_fly"] = np.nan
        out["IOD_per_fly"] = np.nan
    return pd.DataFrame([out])


def annotate(bgr: np.ndarray, bw: np.ndarray, df: pd.DataFrame) -> np.ndarray:
    out = bgr.copy()
    contours, _ = cv2.findContours(bw, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(out, contours, -1, (0, 255, 0), 2)
    for _, r in df.iterrows():
        if np.isnan(r["X"]) or np.isnan(r["Y"]):
            continue
        cv2.putText(
            out,
            str(int(r["DepositID"])),
            (int(r["X"]), int(r["Y"])),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 0, 255),
            2,
        )
    return out


CSS = """
<style>
    .panel {
        border: 1px solid rgba(0,0,0,0.08);
        border-radius: 18px;
        padding: 14px 16px 10px 16px;
        background: rgba(255,255,255,0.75);
        backdrop-filter: blur(6px);
        box-shadow: 0 8px 20px rgba(0,0,0,0.05);
        margin-bottom: 14px;
    }
    .panel h3 {
        margin-top: 0px;
        margin-bottom: 10px;
        font-weight: 650;
        letter-spacing: 0.2px;
    }
    .tiny {
        color: rgba(0,0,0,0.55);
        font-size: 12px;
        margin-top: 6px;
        margin-bottom: 6px;
    }
    .bar {
        border: 1px solid rgba(0,0,0,0.08);
        border-radius: 16px;
        padding: 10px 14px;
        background: rgba(255,255,255,0.85);
        box-shadow: 0 8px 20px rgba(0,0,0,0.05);
    }
</style>
"""


def panel_open(title: str) -> None:
    st.markdown(f'<div class="panel"><h3>{title}</h3>', unsafe_allow_html=True)


def panel_close() -> None:
    st.markdown("</div>", unsafe_allow_html=True)


def load_session_json(file) -> Dict:
    if file is None:
        return {}
    try:
        return json.loads(file.read().decode("utf-8"))
    except Exception:
        return {}


def params_from_session(session: Dict) -> Params:
    p = Params()
    for k, v in (session or {}).items():
        if hasattr(p, k):
            try:
                setattr(p, k, v)
            except Exception:
                pass
    return p


def derive_threshold_params(p: Params) -> Params:
    s = max(0.0, float(p.sensitivity))
    if s <= 100.0:
        block_size = float(np.interp(s, [0, 100], [71, 15]))
        offset_c = float(np.interp(s, [0, 100], [18, 4]))
    else:
        extra = s - 100.0
        block_size = 15.0 - (15.0 - 3.0) * (extra / (extra + 100.0))
        offset_c = 4.0 - (4.0 - 0.0) * (extra / (extra + 100.0))
    block_size = int(round(block_size))
    block_size = max(3, block_size)
    if block_size % 2 == 0:
        block_size += 1
    offset_c = int(round(offset_c))
    offset_c = max(0, offset_c)
    p.adaptive_block_size = block_size
    p.adaptive_offset_c = offset_c
    return p


def left_panel(session_defaults: Dict) -> Tuple[Optional[Image.Image], Optional[ROI], Optional[float]]:
    panel_open("1) Input & ROI")
    uploaded_img = st.file_uploader(
        "Upload image", type=["png", "jpg", "jpeg", "tif", "tiff"], key="img_uploader"
    )
    session_file = st.file_uploader(
        "Load session JSON (optional)", type=["json"], key="session_uploader"
    )
    if session_file is not None:
        loaded = load_session_json(session_file)
        if loaded:
            st.session_state["session_defaults"] = loaded
            st.success("Session loaded. (You can reuse saved ROI/settings.)")
        else:
            st.error("Could not read session JSON.")
    session_defaults = st.session_state.get("session_defaults", session_defaults or {})
    has_saved_roi = isinstance(session_defaults.get("roi"), dict)
    use_saved_roi = st.checkbox(
        "Use ROI from loaded session (skip drawing)",
        value=False,
        disabled=not has_saved_roi,
        help="Load a session JSON first to enable this option.",
    )
    if uploaded_img is None:
        st.info("Upload an image to start.")
        panel_close()
        return None, None, None
    img = Image.open(uploaded_img).convert("RGB")
    W, H = img.size
    disp, scale = resize_for_display(img, max_w=1100)
    draw_mode = "rect"
    cA, cB = st.columns([1, 1])
    with cA:
        if st.button("Clear drawing"):
            st.session_state["canvas_key"] = st.session_state.get("canvas_key", 0) + 1
    with cB:
        st.caption("Draw ONE rectangle. Last shape wins.")
    roi: Optional[ROI] = None
    if use_saved_roi and has_saved_roi:
        try:
            saved = session_defaults.get("roi", {})
            if str(saved.get("kind", "")).lower() != "rect":
                raise ValueError("Saved ROI is not a rect; redraw required.")
            roi = ROI(**saved).clamp(W, H)
            st.success("Using ROI from session.")
        except Exception:
            st.error("Saved ROI in session JSON is invalid or not rectangular. Please redraw.")
            roi = None
    else:
        canvas = st_canvas(
            fill_color="rgba(0, 0, 0, 0)",
            stroke_width=3,
            stroke_color="#00FF00",
            background_image=disp,
            update_streamlit=True,
            height=disp.size[1],
            width=disp.size[0],
            drawing_mode="rect",
            key=f"canvas_{st.session_state.get('canvas_key', 0)}",
        )
        if canvas.json_data:
            roi = roi_from_canvas(canvas.json_data, draw_mode="rect", scale=scale)
            if roi is not None:
                roi = roi.clamp(W, H)
    if roi is not None:
        with st.expander("Fine-adjust ROI (keep shape)", expanded=False):
            if roi.kind == "rect":
                dx = st.slider("Expand X (px)", -500, 500, 0, key="roi_expand_x")
                dy = st.slider("Expand Y (px)", -500, 500, 0, key="roi_expand_y")
                roi.x0 -= dx
                roi.x1 += dx
                roi.y0 -= dy
                roi.y1 += dy
            else:
                dr = st.slider("Adjust radius (px)", -500, 500, 0, key="roi_adjust_r")
                assert roi.r is not None and roi.cx is not None and roi.cy is not None
                roi.r = max(1, roi.r + dr)
                roi.x0 = roi.cx - roi.r
                roi.x1 = roi.cx + roi.r
                roi.y0 = roi.cy - roi.r
                roi.y1 = roi.cy + roi.r
            roi = roi.clamp(W, H)
    panel_close()
    return img, roi, scale


def mid_panel(session_defaults: Dict) -> Params:
    panel_open("2) Parameters & Outputs")
    p = params_from_session(session_defaults)
    p = derive_threshold_params(p)
    p.min_area = st.number_input(
        "Min deposit area (px)", min_value=1, max_value=50000, value=int(p.min_area)
    )
    p.max_area = st.number_input(
        "Max deposit area (px)", min_value=10, max_value=500000, value=int(p.max_area)
    )
    st.session_state.setdefault("sens_max", 200)
    p.sensitivity = int(
        st.number_input(
            "Sensitivity",
            min_value=0,
            value=int(getattr(p, "sensitivity", 0) or 0),
            step=1,
            help="Higher values generally detect more/stronger deposits (mapped to adaptive threshold params).",
            key="sensitivity_exact",
        )
    )
    if p.sensitivity > int(st.session_state.sens_max):
        st.session_state.sens_max = int(max(int(st.session_state.sens_max) * 2, p.sensitivity))
    p.n_flies = st.number_input(
        "No. flies", min_value=0, max_value=1000, value=int(p.n_flies), step=1
    )
    p.use_arenas = st.checkbox(
        "Only count inside white arenas", value=bool(p.use_arenas)
    )

    # Background mask selection UI
    bg_display_map = {"none": "None", "preset": "Preset colour mask", "sample": "Sample background"}
    rev_display_map = {v: k for k, v in bg_display_map.items()}
    # Determine current display text from stored value
    current_display = bg_display_map.get(p.background_method, "Preset colour mask")
    bg_options = list(bg_display_map.values())
    try:
        idx_current = bg_options.index(current_display)
    except ValueError:
        idx_current = 1  # default to preset
    bg_selection = st.selectbox("Background mask", bg_options, index=idx_current)
    p.background_method = rev_display_map.get(bg_selection, "preset")
    # Update remove_pink_background flag for backwards compatibility
    if p.background_method == "none":
        p.remove_pink_background = False
    else:
        p.remove_pink_background = True
    if p.background_method == "preset":
        # Choose preset colour and load defaults
        colour_keys = list(PRESET_BG_COLORS.keys())
        # Ensure current preset is valid
        current_colour = p.bg_color_preset if p.bg_color_preset in colour_keys else "Pink"
        try:
            colour_index = colour_keys.index(current_colour)
        except ValueError:
            colour_index = 0
        p.bg_color_preset = st.selectbox("Background colour", colour_keys, index=colour_index)
        defaults = PRESET_BG_COLORS.get(p.bg_color_preset)
        # If preset is not Custom, assign its default thresholds
        if defaults is not None and p.bg_color_preset != "Custom":
            d_h_low, d_h_high, d_s_min, d_v_min = defaults
            p.pink_h_low, p.pink_h_high, p.pink_s_min, p.pink_v_min = d_h_low, d_h_high, d_s_min, d_v_min
    elif p.background_method == "sample":
        st.caption(
            "After selecting an ROI, draw a rectangle on the ROI crop (see Masks tab) to sample background colour."
        )

    p = derive_threshold_params(p)
    with st.expander("Advanced", expanded=False):
        p.rod_circularity_cutoff = st.slider(
            "ROD circularity cutoff", 0.0, 1.0, float(p.rod_circularity_cutoff), 0.01
        )
        p.morph_open = st.slider("Morph OPEN", 0, 15, int(p.morph_open), 1)
        p.morph_close = st.slider("Morph CLOSE", 0, 25, int(p.morph_close), 1)
        if p.background_method == "preset":
            st.markdown("**Background mask (HSV)**")
            p.pink_h_low = st.slider("Hue low", 0, 179, int(p.pink_h_low))
            p.pink_h_high = st.slider("Hue high", 0, 179, int(p.pink_h_high))
            p.pink_s_min = st.slider("Sat min", 0, 255, int(p.pink_s_min))
            p.pink_v_min = st.slider("Val min", 0, 255, int(p.pink_v_min))
            p.pink_close = st.slider("Close kernel", 0, 51, int(p.pink_close), 2)
        elif p.background_method == "sample":
            st.markdown("**Sampled mask options**")
            # Only morphological closing is adjustable for sampled masks
            p.pink_close = st.slider("Close kernel", 0, 51, int(p.pink_close), 2)
        if p.use_arenas:
            st.markdown("**Arena mask (white circles)**")
            p.arena_s_max = st.slider("Arena S max", 0, 255, int(p.arena_s_max))
            p.arena_v_min = st.slider("Arena V min", 0, 255, int(p.arena_v_min))
            p.arena_close = st.slider("Arena close", 0, 35, int(p.arena_close))
            p.arena_erode = st.slider("Arena erode", 0, 51, int(p.arena_erode), 2)
            p.arena_min_area = st.slider(
                "Arena min area", 1000, 500000, int(p.arena_min_area)
            )
            p.arena_max_area = st.slider(
                "Arena max area", 1000, 2000000, int(p.arena_max_area)
            )
    with st.expander("Notes: how metrics are calculated", expanded=False):
        st.markdown(
            "- **Area / Perimeter / Circularity** are measured from each detected contour.  \n"
            "- **Circularity** = `4π × Area / Perimeter²` (1.0 is a perfect circle).  \n"
            "- **ROD** is flagged when Circularity < cutoff (more oblong deposits).  \n"
            "- **Mean RGB/HSL** values are *normalized to 0–1* and computed as the mean pixel intensity inside each deposit mask.  \n"
            "- **IOD (integrated optical density)** is computed as `Area × (1 − MeanL)` (darker deposits → larger IOD)."
        )
        st.caption(
            "Concise note: Using the background as a zero reference, color intensities are reported as normalized (0–1) "
            "mean RGB/HSL values within each detected deposit."
        )
    panel_close()
    return p


def compute_results(img: Image.Image, roi: ROI, p: Params):
    W, H = img.size
    roi = roi.clamp(W, H)
    roi_mask_full = make_roi_mask(W, H, roi)
    crop_img = img.crop((roi.x0, roi.y0, roi.x1, roi.y1))
    roi_mask_crop = roi_mask_full[roi.y0 : roi.y1, roi.x0 : roi.x1]
    crop_display = (
        apply_mask_alpha(crop_img, roi_mask_crop)
        if roi.kind == "circle"
        else crop_img
    )
    crop_bgr = pil_to_bgr(crop_img)
    gray = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2GRAY)
    bw = adaptive_threshold(
        gray, block_size=p.adaptive_block_size, c=p.adaptive_offset_c
    )
    bw = morphology(bw, open_k=int(p.morph_open), close_k=int(p.morph_close))
    bw = cv2.bitwise_and(bw, bw, mask=roi_mask_crop)
    pink_mask = None
    # Apply background mask according to method
    if p.background_method == "preset" and p.remove_pink_background:
        # Use preset HSV thresholds
        pink_mask = pink_background_mask_hsv(
            crop_bgr,
            h_low=int(p.pink_h_low),
            h_high=int(p.pink_h_high),
            s_min=int(p.pink_s_min),
            v_min=int(p.pink_v_min),
            close_k=int(p.pink_close),
        )
        bw = cv2.bitwise_and(bw, bw, mask=cv2.bitwise_not(pink_mask))
    elif p.background_method == "sample" and p.sample_rect is not None:
        # Compute HSV thresholds from sampled region and apply mask
        try:
            h_low, h_high, s_min, v_min = compute_sample_hsv_range(crop_bgr, p.sample_rect)
            sample_mask = pink_background_mask_hsv(
                crop_bgr,
                h_low=int(h_low),
                h_high=int(h_high),
                s_min=int(s_min),
                v_min=int(v_min),
                close_k=int(p.pink_close),
            )
            pink_mask = sample_mask
            bw = cv2.bitwise_and(bw, bw, mask=cv2.bitwise_not(sample_mask))
        except Exception:
            # If sampling fails, fall back to no mask
            pass
    arena_mask = None
    if p.use_arenas:
        roi_area = int(cv2.countNonZero(roi_mask_crop))
        white_candidate = white_candidate_mask_hsv(
            crop_bgr, s_max=int(p.arena_s_max), v_min=int(p.arena_v_min)
        )
        white_in_roi = cv2.bitwise_and(white_candidate, white_candidate, mask=roi_mask_crop)
        white_area = int(cv2.countNonZero(white_in_roi))
        white_frac = (white_area / roi_area) if roi_area > 0 else 0.0
        if white_frac >= 0.75:
            arena_mask = roi_mask_crop.copy()
        else:
            arena_mask = detect_arenas_white_regions(
                crop_bgr,
                s_max=int(p.arena_s_max),
                v_min=int(p.arena_v_min),
                close_k=int(p.arena_close),
                erode_k=int(p.arena_erode),
                min_area=int(p.arena_min_area),
                max_area=int(p.arena_max_area),
            )
            arena_mask = cv2.bitwise_and(arena_mask, arena_mask, mask=roi_mask_crop)
            if cv2.countNonZero(arena_mask) == 0:
                arena_mask = white_in_roi
        if arena_mask is None or cv2.countNonZero(arena_mask) == 0:
            arena_mask = roi_mask_crop.copy()
        bw = cv2.bitwise_and(bw, bw, mask=arena_mask)
    df, _ = measure_spots_turd_style(
        crop_bgr,
        bw,
        min_area=int(p.min_area),
        max_area=int(p.max_area),
        rod_circ_cutoff=float(p.rod_circularity_cutoff),
    )
    summary = plate_summary(df, int(p.n_flies))
    ann = annotate(crop_bgr, bw, df)
    ann_display = (
        apply_mask_alpha(bgr_to_pil(ann), roi_mask_crop)
        if roi.kind == "circle"
        else bgr_to_pil(ann)
    )
    return {
        "roi": roi,
        "crop_img": crop_img,
        "crop_display": crop_display,
        "crop_bgr": crop_bgr,
        "roi_mask_crop": roi_mask_crop,
        "bw": bw,
        "pink_mask": pink_mask,
        "arena_mask": arena_mask,
        "df": df,
        "summary": summary,
        "ann": ann,
        "ann_display": ann_display,
    }


def right_panel(img: Image.Image, roi: Optional[ROI], p: Params):
    panel_open("3) ROI & Overlay")
    if roi is None:
        st.info("Draw an ROI (left panel) to see results.")
        panel_close()
        return None
    results = compute_results(img, roi, p)
    tab1, tab2, tab3 = st.tabs(["Annotated", "Cropped ROI", "Masks"])
    with tab1:
        st.image(results["ann_display"], use_container_width=True)
    with tab2:
        st.image(results["crop_display"], use_container_width=True)
    with tab3:
        cX, cY = st.columns([1, 1])
        with cX:
            st.caption("Binary map")
            st.image(Image.fromarray(results["bw"]), use_container_width=True)
            st.caption("ROI mask")
            st.image(Image.fromarray(results["roi_mask_crop"]), use_container_width=True)
        with cY:
            if results["pink_mask"] is not None:
                st.caption("Pink mask")
                st.image(Image.fromarray(results["pink_mask"]), use_container_width=True)
            if results["arena_mask"] is not None:
                st.caption("Arena mask")
                st.image(Image.fromarray(results["arena_mask"]), use_container_width=True)

        # Provide sampling canvas when using the sample background method
        if p.background_method == "sample":
            st.markdown("---")
            st.caption("Background sampling: draw a rectangle on the cropped ROI below")
            crop_display = results["crop_display"]
            crop_img = results["crop_img"]
            # Compute scale between displayed crop and actual crop
            scale = 1.0
            try:
                if crop_img.size[0] != 0:
                    scale = crop_display.size[0] / float(crop_img.size[0])
            except Exception:
                pass
            sample_canvas = st_canvas(
                fill_color="rgba(0, 0, 0, 0)",
                stroke_width=2,
                stroke_color="#FF0000",
                background_image=crop_display,
                update_streamlit=True,
                height=crop_display.size[1],
                width=crop_display.size[0],
                drawing_mode="rect",
                key=f"sample_canvas_{st.session_state.get('sample_canvas_key', 0)}",
            )
            sample_rect = None
            if sample_canvas.json_data:
                shape = _get_last_shape(sample_canvas.json_data, "rect")
                if shape:
                    left = float(shape.get("left", 0))
                    top = float(shape.get("top", 0))
                    w_shape = float(shape.get("width", 0)) * float(shape.get("scaleX", 1.0))
                    h_shape = float(shape.get("height", 0)) * float(shape.get("scaleY", 1.0))
                    # Convert to crop coordinates
                    try:
                        x0 = int(left / scale)
                        y0 = int(top / scale)
                        x1 = int((left + w_shape) / scale)
                        y1 = int((top + h_shape) / scale)
                        # Ensure ordering
                        if x1 < x0:
                            x0, x1 = x1, x0
                        if y1 < y0:
                            y0, y1 = y1, y0
                        sample_rect = (x0, y0, x1, y1)
                        p.sample_rect = sample_rect
                        st.session_state["sample_rect"] = sample_rect
                        # Compute thresholds for display
                        try:
                            h_low, h_high, s_min, v_min = compute_sample_hsv_range(results["crop_bgr"], sample_rect)
                            st.session_state["sample_thresholds"] = (h_low, h_high, s_min, v_min)
                            st.success(f"Sampled HSV: H {h_low}–{h_high}, S ≥ {s_min}, V ≥ {v_min}")
                        except Exception:
                            st.warning("Unable to compute sample HSV thresholds.")
                    except Exception:
                        pass
            # If nothing drawn this run but a previous sample exists, display its thresholds
            if sample_rect is None:
                prev_rect = st.session_state.get("sample_rect")
                thresholds = st.session_state.get("sample_thresholds")
                if prev_rect and thresholds:
                    h_low, h_high, s_min, v_min = thresholds
                    st.info(f"Using sampled HSV: H {h_low}–{h_high}, S ≥ {s_min}, V ≥ {v_min}")
    st.markdown("**Quick summary**")
    st.dataframe(results["summary"], use_container_width=True)
    with st.expander("Deposits table", expanded=False):
        st.dataframe(results["df"], use_container_width=True)
    panel_close()
    return results


def bottom_bar(results, roi: Optional[ROI], p: Params) -> None:
    st.markdown('<div class="bar">', unsafe_allow_html=True)
    st.markdown("#### Save / Export")
    session_payload = asdict(p)
    session_payload["roi"] = asdict(roi) if roi is not None else None
    b1, b2, b3, b4 = st.columns([1.2, 1.2, 1.2, 1.2])
    if results is None:
        with b1:
            st.download_button(
                "Download deposits CSV", b"", file_name="spots_turd_style.csv", disabled=True
            )
        with b2:
            st.download_button(
                "Download summary CSV", b"", file_name="plate_summary_turd_style.csv", disabled=True
            )
        with b3:
            st.download_button(
                "Download annotated PNG", b"", file_name="annotated_detection.png", disabled=True
            )
        with b4:
            st.download_button(
                "Download session JSON",
                json.dumps(session_payload, indent=2).encode("utf-8"),
                file_name="session_turd_style.json",
                mime="application/json",
            )
        st.markdown(
            '<div class="tiny">Tip: draw an ROI to enable CSV/PNG exports. You can still save a session JSON now.</div>',
            unsafe_allow_html=True,
        )
        st.markdown("</div>", unsafe_allow_html=True)
        return
    df = results["df"]
    summary = results["summary"]
    with b1:
        st.download_button(
            "Download deposits CSV",
            df.to_csv(index=False).encode("utf-8"),
            file_name="spots_turd_style.csv",
            mime="text/csv",
        )
    with b2:
        st.download_button(
            "Download summary CSV",
            summary.to_csv(index=False).encode("utf-8"),
            file_name="plate_summary_turd_style.csv",
            mime="text/csv",
        )
    with b3:
        buf = BytesIO()
        results["ann_display"].save(buf, format="PNG")
        ann_png = buf.getvalue()
        st.download_button(
            "Download annotated PNG",
            ann_png,
            file_name="annotated_detection.png",
            mime="image/png",
        )
    with b4:
        st.download_button(
            "Download session JSON",
            json.dumps(session_payload, indent=2).encode("utf-8"),
            file_name="session_turd_style.json",
            mime="application/json",
        )
    st.markdown(
        '<div class="tiny">Tip: Save “session JSON” → later reload it (left panel) → tick “Use ROI from loaded session”.</div>',
        unsafe_allow_html=True,
    )
    st.markdown("</div>", unsafe_allow_html=True)


def main() -> None:
    st.set_page_config(
        page_title="TURD-like Spot Detector — Organized Layout", layout="wide"
    )
    st.markdown(CSS, unsafe_allow_html=True)
    st.title("TURD-like Spot Detector")
    st.caption(
        "Mouse ROI (rect/circle) → optional pink background removal → TURD-style measurements"
    )
    st.session_state.setdefault("canvas_key", 0)
    st.session_state.setdefault("session_defaults", {})
    left, mid, right = st.columns([1.25, 1.05, 1.1], gap="large")
    with left:
        img, roi, _scale = left_panel(st.session_state.get("session_defaults", {}))
    with mid:
        p = mid_panel(st.session_state.get("session_defaults", {}))
    results = None
    if img is not None:
        with right:
            results = right_panel(img, roi, p)
    bottom_bar(results, roi, p)

    # Display a methods/differences panel summarising the algorithm
    panel_open("4) Methods & Differences to T.U.R.D.")
    # Summarise which components match the original TURD workflow
    st.markdown(
        "**Same as T.U.R.D.**  "
        "\n- Adaptive thresholding on grayscale images followed by morphological open/close to obtain a binary deposit map." 
        "\n- Contour‐based measurement of each deposit's area, perimeter and circularity." 
        "\n- Classification of deposits as rod‐shaped (ROD) or circular based on a circularity cutoff." 
        "\n- Calculation of integrated optical density (IOD) as `Area × (1 − mean lightness)`.",
        unsafe_allow_html=True,
    )
    # Summarise enhancements implemented in this software
    st.markdown(
        "**New features in this implementation**  "
        "\n- Interactive ROI selection (rectangle or circle) using a canvas." 
        "\n- A single sensitivity control mapped to adaptive threshold parameters for ease of use." 
        "\n- Colour‑based background masking: choose from preset colours or sample a region directly from the image to derive HSV thresholds." 
        "\n- Arena detection to restrict analysis to bright/white regions, reducing false positives." 
        "\n- Export of annotated images, per‐deposit tables, summary CSVs and session JSONs for reproducibility.",
        unsafe_allow_html=True,
    )
    panel_close()


if __name__ == "__main__":
    main()