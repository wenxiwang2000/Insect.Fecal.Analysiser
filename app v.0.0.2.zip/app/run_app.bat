@echo off
REM Helper script to run the TURD‑like Spot Detector Streamlit app on Windows.

REM Change directory to the script location
cd /d %~dp0

REM Create a virtual environment in .venv if it does not exist
IF NOT EXIST ".venv\Scripts\activate" (
    echo Creating virtual environment...
    py -m venv .venv
)

REM Activate the virtual environment
call .venv\Scripts\activate

REM Upgrade pip and install dependencies
echo Installing Python dependencies...
python -m pip install --upgrade pip > nul 2> nul
python -m pip install -r requirements.txt

REM Start the Streamlit app
echo Starting Streamlit app...
python -m streamlit run main.py