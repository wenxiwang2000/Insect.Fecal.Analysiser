#!/bin/bash
# Helper script to run the TURD‑like Spot Detector Streamlit app on Unix/macOS.

set -e

# Determine the directory of this script and switch into it
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Create a virtual environment in .venv if it doesn't exist
if [ ! -d ".venv" ]; then
    echo "Creating virtual environment..."
    python -m venv .venv
fi

# Activate the virtual environment
source .venv/bin/activate

# Upgrade pip and install requirements into the venv
echo "Installing Python dependencies..."
pip install --upgrade pip > /dev/null 2>&1 || true
pip install -r requirements.txt

# Start the Streamlit app
echo "Starting Streamlit app..."
exec streamlit run main.py